####################
Miscellaneous topics
####################

.. toctree::

   callbacks
   server
   rpy_classic
   related_projects
   performances
   graphicaldevices

