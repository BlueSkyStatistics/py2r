####################
High-level interface
####################

.. toctree::

   robjects
   vector
   rhelp
   robjects_convert
   pandas
   graphics
   lib_dplyr
