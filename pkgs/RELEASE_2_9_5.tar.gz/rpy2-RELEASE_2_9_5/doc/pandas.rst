****************************
Interoperability with pandas
****************************

.. note::

   This section is available as a jupyter notebook `pandas.ipynb`_ (HTML render: `pandas.html`_)

   .. _pandas.ipynb: _static/notebooks/pandas.ipynb
   .. _pandas.html: _static/notebooks/pandas.html

.. include:: generated_rst/pandas.rst
