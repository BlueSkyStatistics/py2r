:tocdepth: 2

.. _changes:

Changes in rpy2
***************

.. include:: ../NEWS
