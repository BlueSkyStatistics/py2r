#ifndef _RPY_PRIVATE_BUFFER_H_
#define _RPY_PRIVATE_BUFFER_H_

#ifndef _RPY_RINTERFACE_MODULE_
#error buffer.h should not be included
#endif

static PyBufferProcs VectorSexp_as_buffer;

#endif


