#ifndef _RPY_PRIVATE_NULLVALUE_H_
#define _RPY_PRIVATE_NULLVALUE_H_

#ifndef _RPY_RINTERFACE_MODULE_
#error null_value.h should not be included
#endif

static PyTypeObject RNULL_Type;
static PyTypeObject UnboundValue_Type;

#endif


